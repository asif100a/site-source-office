/**
 * Automatically generated file. DO NOT MODIFY
 */
package expo.modules.image;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "expo.modules.image";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final boolean ALLOW_GLIDE_LOGS = true;
}
